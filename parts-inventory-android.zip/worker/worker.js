// Cloudflare Worker: يستقبل الصور من التطبيق ويرسلها إلى Claude بمفتاحك السري
export default {
  async fetch(req, env) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'content-type,x-app-key',
      'Access-Control-Allow-Methods': 'POST,OPTIONS'
    };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.headers.get('x-app-key') !== env.APP_KEY)
      return new Response('unauthorized', { status: 401, headers: cors });
    const { prompt, images } = await req.json();
    const content = [
      ...(images || []).slice(0, 3).map(d => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: d } })),
      { type: 'text', text: String(prompt || '').slice(0, 8000) }
    ];
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: env.MODEL || 'claude-sonnet-5-5', max_tokens: 1000, messages: [{ role: 'user', content }] })
    });
    const j = await r.json();
    const text = (j.content || []).map(c => c.text || '').join('');
    return new Response(JSON.stringify({ text, error: j.error || null }), {
      status: r.ok ? 200 : 502,
      headers: { ...cors, 'content-type': 'application/json' }
    });
  }
};
