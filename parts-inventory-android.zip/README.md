# تطبيق جرد قطع الموبايلات (Android)

## الطريقة الأسهل: بناء الـ APK على GitHub (بدون تثبيت أي برنامج)
1. أنشئ حساباً مجانياً في github.com ثم اضغط New repository وسمّه مثلاً `parts-inventory`.
2. اضغط "uploading an existing file" ثم **اسحب كل محتويات هذا المجلد** إلى الصفحة (مهم: يجب أن يظهر المجلد `.github`)، ثم Commit changes.
3. افتح تبويب **Actions** ثم **Build APK** ثم **Run workflow**.
4. بعد 5 إلى 10 دقائق يظهر ملف في أسفل صفحة التشغيل باسم **parts-inventory-apk**. حمّله وفك ضغطه.
5. انقل `app-debug.apk` إلى هاتفك وثبّته (فعّل "السماح بالتثبيت من هذا المصدر").

## البديل: Android Studio
```
npm install
npx cap add android
```
أضف السطر التالي داخل `android/app/src/main/AndroidManifest.xml` قبل وسم application:
`<uses-permission android:name="android.permission.CAMERA" />`
ثم:
```
npx cap sync android
npx cap open android
```
ومن Android Studio: Build > Build APK(s).

## تفعيل التعرّف بالذكاء الاصطناعي داخل التطبيق
بدونه يعمل الجرد كاملاً والإدخال يدوي. لتفعيله:
1. أنشئ مفتاح API من console.anthropic.com (كل صورة تُحلَّل تُحتسب كلفتها على حسابك).
2. في cloudflare.com (حساب مجاني): Workers & Pages > Create > Worker > الصق محتوى `worker/worker.js` > Deploy.
3. من Settings > Variables and Secrets أضف سرّين: `ANTHROPIC_API_KEY` (مفتاحك) و`APP_KEY` (أي كلمة سر تختارها).
4. انسخ رابط الـ Worker، وفي التطبيق اضغط زر ⚙️ والصق الرابط ثم كلمة السر.

## ملاحظات
- البيانات محفوظة داخل الهاتف. استخدم زر النسخة الاحتياطية (يفتح قائمة المشاركة لحفظ الملف في Drive أو واتساب).
- الـ APK الناتج نسخة تجريبية (debug) تصلح للاستخدام الشخصي، وللنشر في Google Play يلزم توقيع نسخة release.
